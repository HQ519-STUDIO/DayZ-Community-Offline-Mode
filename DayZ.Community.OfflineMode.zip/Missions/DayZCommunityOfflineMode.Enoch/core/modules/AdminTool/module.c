/*
    Define used for optional compilations
*/
#define MODULE_ADMIN_TOOL

/*
    Include of all .c files that belong to this module
*/
//#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Enoch\\core\\modules\\Admintool\\gui\\PositionMenu.c"