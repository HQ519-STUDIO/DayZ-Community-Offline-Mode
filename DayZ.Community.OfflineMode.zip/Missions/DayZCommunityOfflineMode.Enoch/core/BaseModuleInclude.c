#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Enoch\\core\\ModuleManager.c"
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Enoch\\core\\StaticFunctions.c"

#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Enoch\\core\\CommunityOfflineClient.c"
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Enoch\\core\\CommunityOfflineServer.c"