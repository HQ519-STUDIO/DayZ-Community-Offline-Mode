#include "$CurrentDir:missions\\DayZCommunityOfflineMode.ChernarusPlus\\core\\ModuleManager.c"
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.ChernarusPlus\\core\\StaticFunctions.c"

#include "$CurrentDir:missions\\DayZCommunityOfflineMode.ChernarusPlus\\core\\CommunityOfflineClient.c"
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.ChernarusPlus\\core\\CommunityOfflineServer.c"