class HandData : ItemData
{
    
}