class InventoryData : ItemData
{
    
}