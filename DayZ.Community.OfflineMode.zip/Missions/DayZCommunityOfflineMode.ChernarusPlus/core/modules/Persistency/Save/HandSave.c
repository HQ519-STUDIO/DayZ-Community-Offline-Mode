class HandSave : ItemSave
{
}