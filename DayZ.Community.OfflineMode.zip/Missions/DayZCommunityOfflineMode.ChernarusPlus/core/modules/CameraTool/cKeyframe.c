class cKeyframe 
{
	vector position;
	vector orientation;

	float fov;
}

// static proto native void InterpolateTo(Camera targetCamera, float time, int type);