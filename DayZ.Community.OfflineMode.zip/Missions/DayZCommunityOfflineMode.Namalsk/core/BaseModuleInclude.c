#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Namalsk\\core\\ModuleManager.c"
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Namalsk\\core\\StaticFunctions.c"

#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Namalsk\\core\\CommunityOfflineClient.c"
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Namalsk\\core\\CommunityOfflineServer.c"